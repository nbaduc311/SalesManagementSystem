package system.services;

import system.models.entity.TaiKhoanNguoiDung;

import java.sql.SQLException;
import java.util.List;

public interface TaiKhoanNguoiDungService {
    TaiKhoanNguoiDung themTaiKhoan(TaiKhoanNguoiDung account) throws SQLException;

    TaiKhoanNguoiDung timTheoMa(String maNguoiDung) throws SQLException;

    TaiKhoanNguoiDung timTheoUsername(String username) throws SQLException;
    
    TaiKhoanNguoiDung findByUsernameAndPassword(String username, String password);

    boolean capNhatTaiKhoan(TaiKhoanNguoiDung account) throws SQLException;

    boolean xoaTaiKhoan(String maNguoiDung) throws SQLException;

    List<TaiKhoanNguoiDung> layTatCa() throws SQLException;
}
