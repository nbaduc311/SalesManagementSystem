package system.controllers;

import system.services.RegisterService;
import system.services.impl.RegisterServiceImpl;
import system.models.entity.TaiKhoanNguoiDung;
import system.view.RegisterForm;

public class RegisterController {
    private final RegisterForm form;
    private final RegisterService registerService;

    public RegisterController(RegisterForm form) {
        this.form = form;
        this.registerService = new RegisterServiceImpl();
    }

    /**
     * Gọi khi người dùng nhấn nút Đăng ký
     */
    public void register(String name, String email, String password, String confirmPassword) {
        try {
            TaiKhoanNguoiDung taiKhoan = registerService.dangKy(name, email, password, confirmPassword);
            if (taiKhoan != null) {
                form.showMessage("Đăng ký thành công!");
                form.closeForm();
            } else {
                form.showMessage("Đăng ký thất bại!");
            }
        } catch (Exception e) {
            form.showMessage("Lỗi: " + e.getMessage());
        }
    }
}
