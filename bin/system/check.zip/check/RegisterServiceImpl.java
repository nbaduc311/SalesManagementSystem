package system.services.impl;

import system.models.entity.TaiKhoanNguoiDung;
import system.services.RegisterService;
import system.services.TaiKhoanNguoiDungService;
import system.services.impl.TaiKhoanNguoiDungServiceImpl;

public class RegisterServiceImpl implements RegisterService {

    private final TaiKhoanNguoiDungService taiKhoanService = new TaiKhoanNguoiDungServiceImpl();

    @Override
    public TaiKhoanNguoiDung dangKy(String tenNguoiDung, String email, String matKhau, String xacNhanMatKhau) throws Exception {
        if (tenNguoiDung.isEmpty() || email.isEmpty() || matKhau.isEmpty() || xacNhanMatKhau.isEmpty()) {
            throw new Exception("Vui lòng điền đầy đủ thông tin.");
        }

        if (!matKhau.equals(xacNhanMatKhau)) {
            throw new Exception("Mật khẩu xác nhận không khớp.");
        }

        // Kiểm tra trùng tên tài khoản
        TaiKhoanNguoiDung existing = taiKhoanService.timTheoUsername(email);
        if (existing != null) {
            throw new Exception("Tài khoản đã tồn tại.");
        }

        // Tạo tài khoản mới
        TaiKhoanNguoiDung newAccount = new TaiKhoanNguoiDung();
        newAccount.setUsername(tenNguoiDung);
        newAccount.setEmail(email); // username = email
        newAccount.setPassword(matKhau);
        newAccount.setLoaiNguoiDung("Khách hàng"); // mặc định là Customer

        return taiKhoanService.themTaiKhoan(newAccount);
    }
}
