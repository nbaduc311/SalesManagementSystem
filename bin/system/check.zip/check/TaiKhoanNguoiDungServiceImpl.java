package system.services.impl;

import system.models.dao.TaiKhoanNguoiDungDAO;
import system.models.dao.impl.TaiKhoanNguoiDungDAOImpl;
import system.models.entity.TaiKhoanNguoiDung;
import system.services.TaiKhoanNguoiDungService;
import system.database.DatabaseConnection;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class TaiKhoanNguoiDungServiceImpl implements TaiKhoanNguoiDungService {
    private final TaiKhoanNguoiDungDAO taiKhoanDAO;

    public TaiKhoanNguoiDungServiceImpl() {
        this.taiKhoanDAO = new TaiKhoanNguoiDungDAOImpl();
    }

    @Override
    public TaiKhoanNguoiDung themTaiKhoan(TaiKhoanNguoiDung account) throws SQLException {
        try (Connection conn = DatabaseConnection.getConnection()) {
            return taiKhoanDAO.add(conn, account);
        }
    }

    @Override
    public TaiKhoanNguoiDung timTheoMa(String maNguoiDung) throws SQLException {
        try (Connection conn = DatabaseConnection.getConnection()) {
            return taiKhoanDAO.getById(conn, maNguoiDung);
        }
    }

    @Override
    public TaiKhoanNguoiDung timTheoUsername(String username) throws SQLException {
        try (Connection conn = DatabaseConnection.getConnection()) {
            return taiKhoanDAO.getTaiKhoanByUsername(conn, username);
        }
    }
    
    @Override
    public TaiKhoanNguoiDung findByUsernameAndPassword(String username, String password) {
        return taiKhoanDAO.findByUsernameAndPassword(username, password);
    }


    @Override
    public boolean capNhatTaiKhoan(TaiKhoanNguoiDung account) throws SQLException {
        try (Connection conn = DatabaseConnection.getConnection()) {
            return taiKhoanDAO.update(conn, account);
        }
    }

    @Override
    public boolean xoaTaiKhoan(String maNguoiDung) throws SQLException {
        try (Connection conn = DatabaseConnection.getConnection()) {
            return taiKhoanDAO.delete(conn, maNguoiDung);
        }
    }

    @Override
    public List<TaiKhoanNguoiDung> layTatCa() throws SQLException {
        return taiKhoanDAO.getAll(); // phương thức này tự mở connection bên trong
    }
}
