package system.models.dao.impl; // Corrected package to dao.impl

import system.models.dao.TaiKhoanNguoiDungDAO; // Import the interface
import system.models.entity.TaiKhoanNguoiDung;
import system.database.*; // Ensure this import path is correct for your DatabaseConnection utility

import java.sql.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Concrete implementation of the TaiKhoanNguoiDungDAO interface.
 * This class handles all direct database interactions for the TaiKhoanNguoiDung entity.
 */
public class TaiKhoanNguoiDungDAOImpl implements TaiKhoanNguoiDungDAO {

    /**
     * Thêm một tài khoản người dùng mới vào cơ sở dữ liệu.
     * Vì MaNguoiDung và InternalID được tạo tự động bởi CSDL,
     * chúng ta sẽ chèn các trường còn lại và sau đó truy vấn lại để lấy đầy đủ thông tin tài khoản.
     *
     * @param conn Connection đến cơ sở dữ liệu, được quản lý bởi tầng service.
     * @param account Đối tượng TaiKhoanNguoiDung cần thêm.
     * @return TaiKhoanNguoiDung Đối tượng TaiKhoanNguoiDung đã được thêm (bao gồm MaNguoiDung được CSDL tạo),
     * hoặc null nếu thêm thất bại.
     * @throws SQLException Nếu có lỗi SQL trong quá trình thêm.
     */
    @Override
    public TaiKhoanNguoiDung add(Connection conn, TaiKhoanNguoiDung account) throws SQLException {
        String SQL_INSERT = "INSERT INTO TaiKhoanNguoiDung (Username, Password, Email, LoaiNguoiDung, NgayTao, TrangThaiTaiKhoan) VALUES (?, ?, ?, ?, ?, ?)";
        TaiKhoanNguoiDung newAccount = null;

        try (PreparedStatement pstmt = conn.prepareStatement(SQL_INSERT, Statement.RETURN_GENERATED_KEYS)) {

            pstmt.setString(1, account.getUsername());
            pstmt.setString(2, account.getPassword());
            pstmt.setString(3, account.getEmail());
            pstmt.setString(4, account.getLoaiNguoiDung());
            pstmt.setTimestamp(5, new Timestamp(account.getNgayTao().getTime()));
            pstmt.setString(6, account.getTrangThaiTaiKhoan());

            int affectedRows = pstmt.executeUpdate();

            if (affectedRows > 0) {
                try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        // Retrieve the newly added account by its username, assuming username is unique
                        newAccount = getTaiKhoanByUsername(conn, account.getUsername());
                    }
                }
            }
        } catch (SQLException ex) {
            System.err.println("Lỗi khi thêm tài khoản: " + ex.getMessage());
            throw ex; // Re-throw the exception for the service layer to handle
        }
        return newAccount;
    }

    /**
     * Lấy thông tin tài khoản người dùng dựa trên MaNguoiDung.
     *
     * @param conn Connection đến cơ sở dữ liệu, được quản lý bởi tầng service.
     * @param maNguoiDung Mã người dùng cần tìm (là ID).
     * @return TaiKhoanNguoiDung Đối tượng TaiKhoanNguoiDung nếu tìm thấy, ngược lại là null.
     * @throws SQLException Nếu có lỗi SQL trong quá trình lấy.
     */
    @Override
    public TaiKhoanNguoiDung getById(Connection conn, String maNguoiDung) throws SQLException {
        String SQL_SELECT = "SELECT InternalID, MaNguoiDung, Username, Password, Email, LoaiNguoiDung, NgayTao, TrangThaiTaiKhoan FROM TaiKhoanNguoiDung WHERE MaNguoiDung = ?";
        TaiKhoanNguoiDung account = null;

        try (PreparedStatement pstmt = conn.prepareStatement(SQL_SELECT)) {

            pstmt.setString(1, maNguoiDung);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    account = new TaiKhoanNguoiDung();
                    account.setInternalID(rs.getInt("InternalID"));
                    account.setMaNguoiDung(rs.getString("MaNguoiDung"));
                    account.setUsername(rs.getString("Username"));
                    account.setPassword(rs.getString("Password"));
                    account.setEmail(rs.getString("Email"));
                    account.setLoaiNguoiDung(rs.getString("LoaiNguoiDung"));
                    account.setNgayTao(new Date(rs.getTimestamp("NgayTao").getTime()));
                    account.setTrangThaiTaiKhoan(rs.getString("TrangThaiTaiKhoan"));
                }
            }
        } catch (SQLException ex) {
            System.err.println("Lỗi khi lấy tài khoản theo mã: " + ex.getMessage());
            throw ex; // Re-throw the exception
        }
        return account;
    }

    /**
     * Cập nhật thông tin của một tài khoản người dùng hiện có.
     * Không cho phép cập nhật MaNguoiDung và InternalID vì chúng được CSDL quản lý.
     *
     * @param conn Connection đến cơ sở dữ liệu, được quản lý bởi tầng service.
     * @param account Đối tượng TaiKhoanNguoiDung chứa thông tin cập nhật.
     * @return boolean True nếu cập nhật thành công, False nếu thất bại.
     * @throws SQLException Nếu có lỗi SQL trong quá trình cập nhật.
     */
    @Override
    public boolean update(Connection conn, TaiKhoanNguoiDung account) throws SQLException {
        String SQL_UPDATE = "UPDATE TaiKhoanNguoiDung SET Username = ?, Password = ?, Email = ?, LoaiNguoiDung = ?, TrangThaiTaiKhoan = ? WHERE MaNguoiDung = ?";
        boolean success = false;

        try (PreparedStatement pstmt = conn.prepareStatement(SQL_UPDATE)) {

            pstmt.setString(1, account.getUsername());
            pstmt.setString(2, account.getPassword());
            pstmt.setString(3, account.getEmail());
            pstmt.setString(4, account.getLoaiNguoiDung());
            pstmt.setString(5, account.getTrangThaiTaiKhoan());
            pstmt.setString(6, account.getMaNguoiDung()); // Use MaNguoiDung to identify the record

            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) {
                success = true;
            }
        } catch (SQLException ex) {
            System.err.println("Lỗi khi cập nhật tài khoản: " + ex.getMessage());
            throw ex; // Re-throw the exception
        }
        return success;
    }

    /**
     * Xóa một tài khoản người dùng khỏi cơ sở dữ liệu dựa trên MaNguoiDung.
     *
     * @param conn Connection đến cơ sở dữ liệu, được quản lý bởi tầng service.
     * @param maNguoiDung Mã người dùng của tài khoản cần xóa.
     * @return boolean True nếu xóa thành công, False nếu thất bại.
     * @throws SQLException Nếu có lỗi SQL trong quá trình xóa.
     */
    @Override
    public boolean delete(Connection conn, String maNguoiDung) throws SQLException {
        String SQL_DELETE = "DELETE FROM TaiKhoanNguoiDung WHERE MaNguoiDung = ?";
        boolean success = false;

        try (PreparedStatement pstmt = conn.prepareStatement(SQL_DELETE)) {

            pstmt.setString(1, maNguoiDung);

            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) {
                success = true;
            }
        } catch (SQLException ex) {
            System.err.println("Lỗi khi xóa tài khoản: " + ex.getMessage());
            throw ex; // Re-throw the exception
        }
        return success;
    }

    /**
     * Lấy tất cả các tài khoản người dùng từ cơ sở dữ liệu.
     * This method manages its own connection as it's typically used for broad queries
     * and might not be part of a larger transaction.
     *
     * @return List<TaiKhoanNguoiDung> Danh sách các đối tượng TaiKhoanNguoiDung.
     */
    @Override
    public List<TaiKhoanNguoiDung> getAll() {
        List<TaiKhoanNguoiDung> taiKhoanList = new ArrayList<>();
        String SQL_SELECT_ALL = "SELECT InternalID, MaNguoiDung, Username, Password, Email, LoaiNguoiDung, NgayTao, TrangThaiTaiKhoan FROM TaiKhoanNguoiDung";

        try (Connection conn = DatabaseConnection.getConnection(); // Manages its own connection
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(SQL_SELECT_ALL)) {

            while (rs.next()) {
                TaiKhoanNguoiDung account = new TaiKhoanNguoiDung();
                account.setInternalID(rs.getInt("InternalID"));
                account.setMaNguoiDung(rs.getString("MaNguoiDung"));
                account.setUsername(rs.getString("Username"));
                account.setPassword(rs.getString("Password"));
                account.setEmail(rs.getString("Email"));
                account.setLoaiNguoiDung(rs.getString("LoaiNguoiDung"));
                account.setNgayTao(new Date(rs.getTimestamp("NgayTao").getTime()));
                account.setTrangThaiTaiKhoan(rs.getString("TrangThaiTaiKhoan"));
                taiKhoanList.add(account);
            }
        } catch (SQLException ex) {
            System.err.println("Lỗi khi lấy tất cả tài khoản: " + ex.getMessage());
            ex.printStackTrace();
        }
        return taiKhoanList;
    }

    /**
     * Lấy thông tin tài khoản người dùng dựa trên Username.
     * Thường dùng cho chức năng đăng nhập hoặc kiểm tra trùng lặp username.
     * This method accepts a Connection to be part of a transactional context.
     *
     * @param conn Connection đến cơ sở dữ liệu, được quản lý bởi tầng service.
     * @param username Tên đăng nhập cần tìm.
     * @return TaiKhoanNguoiDung Đối tượng TaiKhoanNguoiDung nếu tìm thấy, ngược lại là null.
     * @throws SQLException Nếu có lỗi SQL.
     */
    @Override // This method is now part of the TaiKhoanNguoiDungDAO interface
    public TaiKhoanNguoiDung getTaiKhoanByUsername(Connection conn, String username) throws SQLException {
        String SQL_SELECT = "SELECT InternalID, MaNguoiDung, Username, Password, Email, LoaiNguoiDung, NgayTao, TrangThaiTaiKhoan FROM TaiKhoanNguoiDung WHERE Username = ?";
        TaiKhoanNguoiDung account = null;

        try (PreparedStatement pstmt = conn.prepareStatement(SQL_SELECT)) {

            pstmt.setString(1, username);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    account = new TaiKhoanNguoiDung();
                    account.setInternalID(rs.getInt("InternalID"));
                    account.setMaNguoiDung(rs.getString("MaNguoiDung"));
                    account.setUsername(rs.getString("Username"));
                    account.setPassword(rs.getString("Password"));
                    account.setEmail(rs.getString("Email"));
                    account.setLoaiNguoiDung(rs.getString("LoaiNguoiDung"));
                    account.setNgayTao(new Date(rs.getTimestamp("NgayTao").getTime()));
                    account.setTrangThaiTaiKhoan(rs.getString("TrangThaiTaiKhoan"));
                }
            }
        } catch (SQLException ex) {
            System.err.println("Lỗi khi lấy tài khoản theo username: " + ex.getMessage());
            throw ex; // Re-throw the exception
        }
        return account;
    }
    @Override
    public TaiKhoanNguoiDung findByUsernameAndPassword(String username, String password) {
        TaiKhoanNguoiDung user = null;
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT * FROM TaiKhoanNguoiDung WHERE Username = ? AND Password = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, username);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                user = new TaiKhoanNguoiDung();
                user.setUsername(rs.getString("Username")); 
                user.setPassword(rs.getString("Password"));
                user.setLoaiNguoiDung(rs.getString("LoaiNguoiDung"));
                user.setTrangThaiTaiKhoan(rs.getString("TrangThaiTaiKhoan"));
                // Thêm các thuộc tính khác nếu cần
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return user;
    }

}