package system.services;

import system.models.entity.TaiKhoanNguoiDung;

public interface RegisterService {
    /**
     * Đăng ký tài khoản mới
     * @param tenNguoiDung Họ tên
     * @param email Email
     * @param matKhau Mật khẩu
     * @param xacNhanMatKhau Xác nhận mật khẩu
     * @return TaiKhoanNguoiDung nếu thành công, null nếu lỗi
     * @throws Exception nếu xảy ra lỗi
     */
    TaiKhoanNguoiDung dangKy(String tenNguoiDung, String email, String matKhau, String xacNhanMatKhau) throws Exception;
}
