package system.view;

import javax.swing.*;
import java.awt.*;
import system.components.*;
import system.controllers.RegisterController;

public class RegisterForm extends JFrame {
    private RoundedTextField nameField, emailField;
    private RoundedPasswordField passField, confirmPassField;
    private RegisterController controller;

    public RegisterForm() {
        controller = new RegisterController(this);

        setTitle("\u0110\u0103ng k\u00fd t\u00e0i kho\u1ea3n");
        setSize(450, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(null);

        ImageIcon backgroundIcon = new ImageIcon(getClass().getResource("/img/bg_register.jpg"));
        JLabel backgroundLabel = new JLabel(backgroundIcon);
        backgroundLabel.setBounds(0, 0, 450, 500);
        getLayeredPane().add(backgroundLabel, new Integer(Integer.MIN_VALUE));

        JPanel content = (JPanel) getContentPane();
        content.setOpaque(false);
        content.setLayout(null);
        setIconImage(new ImageIcon(getClass().getResource("/img/logo.png")).getImage());

        JLabel title = new JLabel("T\u1ea1o t\u00e0i kho\u1ea3n m\u1edbi");
        title.setFont(new Font("Arial", Font.BOLD, 24));
        title.setBounds(110, 30, 300, 30);
        add(title);

        JLabel nameLabel = new JLabel("T\u00ean c\u1ee7a b\u1ea1n:");
        nameLabel.setBounds(50, 80, 100, 25);
        add(nameLabel);

        nameField = new RoundedTextField(30);
        nameField.setPlaceholder("\u0110i\u1ec1n t\u00ean");
        nameField.setBounds(50, 110, 330, 35);
        add(nameField);

        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setBounds(50, 150, 100, 25);
        add(emailLabel);

        emailField = new RoundedTextField(30);
        emailField.setPlaceholder("\u0110i\u1ec1n email");
        emailField.setBounds(50, 180, 330, 35);
        add(emailField);

        JLabel passLabel = new JLabel("M\u1eadt kh\u1ea9u:");
        passLabel.setBounds(50, 220, 100, 25);
        add(passLabel);

        passField = new RoundedPasswordField(30);
        passField.setPlaceholder("\u0110i\u1ec1n m\u1eadt kh\u1ea9u");
        passField.setBounds(50, 250, 330, 35);
        add(passField);

        JLabel confirmLabel = new JLabel("X\u00e1c nh\u1eadn m\u1eadt kh\u1ea9u:");
        confirmLabel.setBounds(50, 290, 150, 25);
        add(confirmLabel);

        confirmPassField = new RoundedPasswordField(30);
        confirmPassField.setPlaceholder("\u0110i\u1ec1n x\u00e1c nh\u1eadn m\u1eadt kh\u1ea9u");
        confirmPassField.setBounds(50, 320, 330, 35);
        add(confirmPassField);

        RoundedButton registerBtn = new RoundedButton("\u0110\u0103ng k\u00fd");
        registerBtn.setBounds(125, 380, 180, 40);
        add(registerBtn);

        confirmPassField.addActionListener(e -> {
            registerBtn.setPressedTemporarily();
            Timer timer = new Timer(500, evt -> registerBtn.doClick());
            timer.setRepeats(false);
            timer.start();
        });

        registerBtn.addActionListener(e -> controller.register(
            nameField.getText().trim(),
            emailField.getText().trim(),
            new String(passField.getPassword()),
            new String(confirmPassField.getPassword())
        ));

        setVisible(true);
    }

    public void showMessage(String msg) {
        JOptionPane.showMessageDialog(this, msg);
    }

    public void closeForm() {
        dispose();
    }
}
