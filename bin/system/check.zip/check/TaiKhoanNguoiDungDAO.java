package system.models.dao;

import system.models.entity.TaiKhoanNguoiDung;
import java.sql.Connection;
import java.sql.SQLException;
//import java.util.List;

/**
 * Interface DAO (Data Access Object) for the TaiKhoanNguoiDung (User Account) entity.
 * It extends GenericDAO to provide common CRUD (Create, Read, Update, Delete) operations.
 * Additionally, it defines specific methods for TaiKhoanNguoiDung, such as retrieval by username.
 */
public interface TaiKhoanNguoiDungDAO extends GenericDAO<TaiKhoanNguoiDung, String> { // ID is String for MaNguoiDung

    /**
     * Lấy thông tin tài khoản người dùng dựa trên Username.
     * Thường dùng cho chức năng đăng nhập hoặc kiểm tra trùng lặp username.
     *
     * @param conn Connection đến cơ sở dữ liệu.
     * @param username Tên đăng nhập cần tìm.
     * @return TaiKhoanNguoiDung Đối tượng TaiKhoanNguoiDung nếu tìm thấy, ngược lại là null.
     * @throws SQLException Nếu có lỗi SQL.
     */
    TaiKhoanNguoiDung getTaiKhoanByUsername(Connection conn, String username) throws SQLException;
    TaiKhoanNguoiDung findByUsernameAndPassword(String username, String password);
}